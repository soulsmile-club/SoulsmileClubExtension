import React from 'react';
import './App.css';

function Account() {
    return (
    	<>
	        <div id="soul">Your Account</div>
	        <div id = "message">
	            Stay tuned for a future update that will allow you to log in and view your profile here!
	        </div>
	    </>
    );
}

export default Account;
